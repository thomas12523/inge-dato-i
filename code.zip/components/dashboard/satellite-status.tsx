"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Badge } from "@/components/ui/badge"
import { Satellite } from "lucide-react"

interface SatelliteData {
  idsatelite: number
  nombresatelite: string
  agencia: string
  fecha_lanzamiento: string
  estado: boolean
}

export function SatelliteStatus() {
  const [satellites, setSatellites] = useState<SatelliteData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchSatellites() {
      const supabase = createClient()

      const { data } = await supabase.from("satelite").select("*").order("nombresatelite", { ascending: true })

      setSatellites(data || [])
      setLoading(false)
    }

    fetchSatellites()
  }, [])

  return (
    <Card className="border-slate-800 bg-slate-900/50 backdrop-blur">
      <CardHeader>
        <CardTitle className="text-white">Estado de Satélites</CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-slate-400">Cargando...</p>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {satellites.map((sat) => (
              <div
                key={sat.idsatelite}
                className="flex items-start gap-3 rounded-lg border border-slate-800 bg-slate-800/30 p-4"
              >
                <div className="rounded-lg bg-blue-500/10 p-2">
                  <Satellite className="h-5 w-5 text-blue-400" />
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-white">{sat.nombresatelite}</p>
                      <p className="text-xs text-slate-400">{sat.agencia}</p>
                    </div>
                    <Badge
                      className={
                        sat.estado
                          ? "bg-green-500/10 text-green-400 border-green-500/20"
                          : "bg-red-500/10 text-red-400 border-red-500/20"
                      }
                    >
                      {sat.estado ? "Activo" : "Inactivo"}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-500">
                    Lanzamiento: {new Date(sat.fecha_lanzamiento).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
