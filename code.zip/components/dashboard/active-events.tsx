"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Flame, Droplets, Wind, Activity } from "lucide-react"

interface Event {
  idevento: number
  tipo: string
  fecha_inicio: string
  fecha_fin: string
  severidad: string
  descripcion: string
}

export function ActiveEvents() {
  const [events, setEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchEvents() {
      const supabase = createClient()

      const { data } = await supabase
        .from("eventoclimatico")
        .select("*")
        .order("fecha_inicio", { ascending: false })
        .limit(5)

      setEvents(data || [])
      setLoading(false)
    }

    fetchEvents()
  }, [])

  const getSeverityColor = (severity: string) => {
    const colors: Record<string, string> = {
      Leve: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
      Moderado: "bg-orange-500/10 text-orange-400 border-orange-500/20",
      Severo: "bg-red-500/10 text-red-400 border-red-500/20",
    }
    return colors[severity] || "bg-slate-500/10 text-slate-400"
  }

  const getEventIcon = (type: string) => {
    const icons: Record<string, any> = {
      Huracan: Wind,
      Sequia: Droplets,
      Incendio: Flame,
      Tormenta: AlertTriangle,
      Terremoto: Activity,
    }
    return icons[type] || AlertTriangle
  }

  return (
    <Card className="border-slate-800 bg-slate-900/50 backdrop-blur">
      <CardHeader>
        <CardTitle className="text-white">Eventos Climáticos</CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-slate-400">Cargando...</p>
        ) : (
          <div className="space-y-4">
            {events.map((event) => {
              const Icon = getEventIcon(event.tipo)
              return (
                <div
                  key={event.idevento}
                  className="flex items-start gap-3 rounded-lg border border-slate-800 bg-slate-800/30 p-3"
                >
                  <div className="rounded-lg bg-slate-700/50 p-2">
                    <Icon className="h-4 w-4 text-slate-300" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-white">{event.tipo}</p>
                      <Badge className={getSeverityColor(event.severidad)}>{event.severidad}</Badge>
                    </div>
                    <p className="text-xs text-slate-400 line-clamp-2">{event.descripcion}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(event.fecha_inicio).toLocaleDateString()} -{" "}
                      {new Date(event.fecha_fin).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
