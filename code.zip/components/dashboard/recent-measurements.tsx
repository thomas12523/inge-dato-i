"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Badge } from "@/components/ui/badge"

interface Measurement {
  idmedicion: number
  fecha_hora: string
  valor: number
  calidaddato: string
  satelite: { nombresatelite: string }
  variableclimatica: { codigoclimatico: string; unidad: string }
  region: { nombreregion: string }
}

export function RecentMeasurements() {
  const [measurements, setMeasurements] = useState<Measurement[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchMeasurements() {
      const supabase = createClient()

      const { data } = await supabase
        .from("medicion")
        .select(
          `
          idmedicion,
          fecha_hora,
          valor,
          calidaddato,
          satelite:idsatelite(nombresatelite),
          variableclimatica:idvariableclimatica(codigoclimatico, unidad),
          region:idregion(nombreregion)
        `,
        )
        .order("fecha_hora", { ascending: false })
        .limit(5)

      setMeasurements(data || [])
      setLoading(false)
    }

    fetchMeasurements()
  }, [])

  const getQualityColor = (quality: string) => {
    const colors: Record<string, string> = {
      Excelente: "bg-green-500/10 text-green-400 border-green-500/20",
      "Muy Bueno": "bg-blue-500/10 text-blue-400 border-blue-500/20",
      Medio: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
      Malo: "bg-orange-500/10 text-orange-400 border-orange-500/20",
      Preocupante: "bg-red-500/10 text-red-400 border-red-500/20",
    }
    return colors[quality] || "bg-slate-500/10 text-slate-400"
  }

  return (
    <Card className="border-slate-800 bg-slate-900/50 backdrop-blur">
      <CardHeader>
        <CardTitle className="text-white">Mediciones Recientes</CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-slate-400">Cargando...</p>
        ) : (
          <div className="space-y-4">
            {measurements.map((m) => (
              <div
                key={m.idmedicion}
                className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-800/30 p-3"
              >
                <div className="space-y-1">
                  <p className="text-sm font-medium text-white">
                    {m.variableclimatica.codigoclimatico}: {m.valor} {m.variableclimatica.unidad}
                  </p>
                  <p className="text-xs text-slate-400">
                    {m.region.nombreregion} • {m.satelite.nombresatelite}
                  </p>
                </div>
                <Badge className={getQualityColor(m.calidaddato)}>{m.calidaddato}</Badge>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
