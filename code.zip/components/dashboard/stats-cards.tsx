"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Satellite, MapPin, AlertTriangle, Activity } from "lucide-react"
import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"

interface Stats {
  satellites: number
  regions: number
  activeEvents: number
  measurements: number
}

export function StatsCards() {
  const [stats, setStats] = useState<Stats>({
    satellites: 0,
    regions: 0,
    activeEvents: 0,
    measurements: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchStats() {
      const supabase = createClient()

      const [satellites, regions, events, measurements] = await Promise.all([
        supabase.from("satelite").select("*", { count: "exact", head: true }),
        supabase.from("region").select("*", { count: "exact", head: true }),
        supabase.from("eventoclimatico").select("*", { count: "exact", head: true }),
        supabase.from("medicion").select("*", { count: "exact", head: true }),
      ])

      setStats({
        satellites: satellites.count || 0,
        regions: regions.count || 0,
        activeEvents: events.count || 0,
        measurements: measurements.count || 0,
      })
      setLoading(false)
    }

    fetchStats()
  }, [])

  const cards = [
    {
      title: "Satélites Activos",
      value: stats.satellites,
      icon: Satellite,
      color: "text-blue-400",
      bgColor: "bg-blue-500/10",
    },
    {
      title: "Regiones Monitoreadas",
      value: stats.regions,
      icon: MapPin,
      color: "text-green-400",
      bgColor: "bg-green-500/10",
    },
    {
      title: "Eventos Registrados",
      value: stats.activeEvents,
      icon: AlertTriangle,
      color: "text-orange-400",
      bgColor: "bg-orange-500/10",
    },
    {
      title: "Mediciones Totales",
      value: stats.measurements,
      icon: Activity,
      color: "text-purple-400",
      bgColor: "bg-purple-500/10",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <Card key={card.title} className="border-slate-800 bg-slate-900/50 backdrop-blur">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-200">{card.title}</CardTitle>
            <div className={`rounded-lg p-2 ${card.bgColor}`}>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{loading ? "..." : card.value.toLocaleString()}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
