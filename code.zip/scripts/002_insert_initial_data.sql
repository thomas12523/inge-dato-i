-- Insertar datos iniciales

-- Satélites
INSERT INTO Satelite (nombreSatelite, agencia, fecha_lanzamiento, estado)
VALUES
('Landsat 8', 'NASA', '2013-02-11', true),
('Sentinel-1A', 'ESA', '2014-04-03', true),
('GOES-16', 'NOAA', '2016-11-19', true),
('Terra', 'NASA', '1999-12-18', true),
('Aqua', 'NASA', '2002-05-04', true),
('Himawari-8', 'JMA', '2014-10-07', true),
('MetOp-B', 'EUMETSAT', '2012-09-17', true),
('NOAA-20', 'NOAA', '2017-11-18', true),
('Suomi NPP', 'NASA', '2011-10-28', true),
('Sentinel-2B', 'ESA', '2017-03-07', true)
ON CONFLICT DO NOTHING;

-- Variables Climáticas
INSERT INTO VariableClimatica (codigoClimatico, nombreVariableClimatica, unidad)
VALUES
('TEMP', 'Temperatura del aire', 'Centigrados'),
('CO2', 'Concentración de dióxido de carbono', 'ppm'),
('HUM', 'Humedad relativa', '%'),
('WSPD', 'Velocidad del viento', 'm/s'),
('PRES', 'Presión atmosférica', 'hPa')
ON CONFLICT (codigoClimatico) DO NOTHING;

-- Regiones
INSERT INTO Region (nombreRegion, latitudCentro, longitudCentro, poblacion)
VALUES
('Buenos Aires', -34.6037, -58.3816, 15000000),
('Cordoba', -31.4201, -64.1888, 3500000),
('Rosario', -32.9587, -60.6939, 1300000),
('Mendoza', -32.8908, -68.8272, 2000000),
('Salta', -24.7829, -65.4232, 1400000),
('Tucuman', -26.8083, -65.2176, 1700000),
('La Plata', -34.9214, -57.9544, 800000),
('Neuquen', -38.9516, -68.0591, 700000),
('Mar del Plata', -38.0023, -57.5575, 900000),
('San Juan', -31.5375, -68.5364, 850000)
ON CONFLICT DO NOTHING;

-- Eventos Climáticos
INSERT INTO EventoClimatico (tipo, fecha_inicio, fecha_fin, severidad, descripcion)
VALUES
('Huracan', '2022-02-01', '2022-02-05', 'Severo', 'Huracán categoría 4 en el Atlántico Sur'),
('Sequia', '2021-11-01', '2022-03-01', 'Moderado', 'Escasez prolongada de lluvias en el norte'),
('Incendio', '2023-01-10', '2023-01-15', 'Severo', 'Incendios forestales en la Patagonia'),
('Tormenta', '2024-05-12', '2024-05-14', 'Leve', 'Tormenta eléctrica con granizo en el litoral'),
('Terremoto', '2020-06-20', '2020-06-21', 'Moderado', 'Sismo leve en el oeste argentino'),
('Huracan', '2023-09-01', '2023-09-04', 'Leve', 'Vientos fuertes en la costa este'),
('Sequia', '2019-07-01', '2019-12-01', 'Severo', 'Sequía histórica en zona central'),
('Incendio', '2024-12-10', '2024-12-15', 'Moderado', 'Fuego en reservas naturales del norte'),
('Tormenta', '2022-09-05', '2022-09-07', 'Leve', 'Tormenta tropical menor'),
('Terremoto', '2023-03-15', '2023-03-16', 'Moderado', 'Movimiento sísmico superficial')
ON CONFLICT DO NOTHING;

-- Mediciones
INSERT INTO Medicion (fecha_hora, valor, calidadDato, idSatelite, idVariableClimatica, idRegion)
VALUES
('2025-01-10 10:00:00', 28.5, 'Excelente', 1, 1, 1),
('2025-01-10 10:05:00', 400.2, 'Muy Bueno', 2, 2, 2),
('2025-01-10 10:10:00', 65.0, 'Medio', 3, 3, 3),
('2025-01-10 10:15:00', 5.8, 'Excelente', 4, 4, 4),
('2025-01-10 10:20:00', 1013.5, 'Muy Bueno', 5, 5, 5),
('2025-01-11 09:00:00', 30.1, 'Excelente', 6, 1, 6),
('2025-01-11 09:05:00', 410.0, 'Preocupante', 7, 2, 7),
('2025-01-11 09:10:00', 70.5, 'Malo', 8, 3, 8),
('2025-01-11 09:15:00', 6.3, 'Muy Bueno', 9, 4, 9),
('2025-01-11 09:20:00', 1005.0, 'Excelente', 10, 5, 10)
ON CONFLICT DO NOTHING;

-- Evento_Region
INSERT INTO Evento_Region (idEvento, idRegion, fecha_impacto)
VALUES
(1, 4, '2024-12-10'),
(2, 1, '2025-02-10'),
(3, 5, '2025-01-06'),
(4, 9, '2024-11-22'),
(5, 10, '2024-10-10'),
(6, 3, '2023-09-20'),
(7, 6, '2024-02-02'),
(8, 8, '2025-03-20'),
(9, 2, '2023-12-16'),
(10, 7, '2025-04-01')
ON CONFLICT DO NOTHING;
