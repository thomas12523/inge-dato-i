-- Crear tablas principales del sistema de monitoreo climático

-- Tabla Satelite
CREATE TABLE IF NOT EXISTS Satelite (
  idSatelite SERIAL PRIMARY KEY,
  nombreSatelite VARCHAR(100) NOT NULL,
  agencia VARCHAR(50) NOT NULL,
  fecha_lanzamiento DATE,
  estado BOOLEAN DEFAULT true,
  CONSTRAINT chkFechaLanzamiento CHECK (EXTRACT(YEAR FROM fecha_lanzamiento) > 1960)
);

-- Tabla VariableClimatica
CREATE TABLE IF NOT EXISTS VariableClimatica (
  idVariableClimatica SERIAL PRIMARY KEY,
  codigoClimatico VARCHAR(10) UNIQUE NOT NULL,
  nombreVariableClimatica VARCHAR(50),
  unidad VARCHAR(20),
  CONSTRAINT chckVariable CHECK (
    (codigoClimatico = 'TEMP' AND unidad = 'Centigrados') OR
    (codigoClimatico = 'CO2' AND unidad = 'ppm') OR
    (codigoClimatico = 'HUM' AND unidad = '%') OR
    (codigoClimatico = 'WSPD' AND unidad = 'm/s') OR
    (codigoClimatico = 'PRES' AND unidad = 'hPa')
  )
);

-- Tabla Region
CREATE TABLE IF NOT EXISTS Region (
  idRegion SERIAL PRIMARY KEY,
  nombreRegion VARCHAR(100) NOT NULL,
  latitudCentro DECIMAL(8,5) NOT NULL,
  longitudCentro DECIMAL(8,5) NOT NULL,
  poblacion INTEGER,
  CONSTRAINT checkLatYLong CHECK (
    latitudCentro BETWEEN -90 AND 90 AND
    longitudCentro BETWEEN -180 AND 180
  ),
  CONSTRAINT chckPopulation CHECK (poblacion > 0)
);

-- Tabla EventoClimatico
CREATE TABLE IF NOT EXISTS EventoClimatico (
  idEvento SERIAL PRIMARY KEY,
  tipo VARCHAR(50) NOT NULL,
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NOT NULL,
  severidad VARCHAR(20) NOT NULL,
  descripcion TEXT,
  CONSTRAINT ck_EventoClimatico_Fechas CHECK (
    fecha_inicio <= fecha_fin AND EXTRACT(YEAR FROM fecha_inicio) >= 1960
  ),
  CONSTRAINT ck_EventoClimatico_Severidad CHECK (
    severidad IN ('Leve', 'Moderado', 'Severo')
  ),
  CONSTRAINT ck_EventoClimatico_Tipo CHECK (
    tipo IN ('Huracan', 'Sequia', 'Incendio', 'Tormenta', 'Terremoto')
  )
);

-- Tabla Medicion
CREATE TABLE IF NOT EXISTS Medicion (
  idMedicion SERIAL PRIMARY KEY,
  fecha_hora TIMESTAMP NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  calidadDato VARCHAR(20),
  idSatelite INTEGER REFERENCES Satelite(idSatelite),
  idVariableClimatica INTEGER REFERENCES VariableClimatica(idVariableClimatica),
  idRegion INTEGER REFERENCES Region(idRegion),
  CONSTRAINT chckCalidadDato CHECK (
    calidadDato IN ('Excelente', 'Muy Bueno', 'Medio', 'Malo', 'Preocupante')
  )
);

-- Tabla Evento_Region (relación N:N)
CREATE TABLE IF NOT EXISTS Evento_Region (
  idEventoRegion SERIAL PRIMARY KEY,
  idEvento INTEGER REFERENCES EventoClimatico(idEvento),
  idRegion INTEGER REFERENCES Region(idRegion),
  fecha_impacto DATE
);

-- Habilitar Row Level Security en todas las tablas
ALTER TABLE Satelite ENABLE ROW LEVEL SECURITY;
ALTER TABLE VariableClimatica ENABLE ROW LEVEL SECURITY;
ALTER TABLE Region ENABLE ROW LEVEL SECURITY;
ALTER TABLE EventoClimatico ENABLE ROW LEVEL SECURITY;
ALTER TABLE Medicion ENABLE ROW LEVEL SECURITY;
ALTER TABLE Evento_Region ENABLE ROW LEVEL SECURITY;

-- Políticas RLS: permitir lectura a todos los usuarios autenticados
CREATE POLICY "Allow authenticated read on Satelite" ON Satelite FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read on VariableClimatica" ON VariableClimatica FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read on Region" ON Region FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read on EventoClimatico" ON EventoClimatico FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read on Medicion" ON Medicion FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow authenticated read on Evento_Region" ON Evento_Region FOR SELECT TO authenticated USING (true);
