import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { RecentMeasurements } from "@/components/dashboard/recent-measurements"
import { ActiveEvents } from "@/components/dashboard/active-events"
import { SatelliteStatus } from "@/components/dashboard/satellite-status"

export default async function DashboardPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900">
      <DashboardHeader user={data.user} />

      <main className="container mx-auto p-6 space-y-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400 mt-2">Monitoreo en tiempo real de variables climáticas satelitales</p>
        </div>

        <StatsCards />

        <div className="grid gap-6 lg:grid-cols-2">
          <RecentMeasurements />
          <ActiveEvents />
        </div>

        <SatelliteStatus />
      </main>
    </div>
  )
}
