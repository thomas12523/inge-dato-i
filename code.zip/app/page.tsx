import { Button } from "@/components/ui/button"
import { Satellite, BarChart3, Globe, Shield } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur">
        <div className="container mx-auto flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <div className="rounded-lg bg-blue-600 p-2">
              <Satellite className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-white">Climate Monitor</span>
          </div>
          <div className="flex gap-3">
            <Button asChild variant="ghost" className="text-slate-300 hover:text-white">
              <Link href="/auth/login">Iniciar Sesión</Link>
            </Button>
            <Button asChild className="bg-blue-600 hover:bg-blue-700">
              <Link href="/auth/sign-up">Registrarse</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-24 text-center">
        <div className="mx-auto max-w-3xl space-y-6">
          <div className="mb-8 flex justify-center">
            <div className="rounded-full bg-blue-600/20 p-6">
              <Satellite className="h-16 w-16 text-blue-400" />
            </div>
          </div>
          <h1 className="text-5xl font-bold leading-tight text-white lg:text-6xl">
            Sistema de Monitoreo Climático Satelital
          </h1>
          <p className="text-xl text-slate-300 leading-relaxed">
            Plataforma empresarial para el análisis y seguimiento de variables climáticas mediante datos satelitales en
            tiempo real
          </p>
          <div className="flex justify-center gap-4 pt-6">
            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Link href="/auth/sign-up">Comenzar Ahora</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-slate-700 text-white hover:bg-slate-800 bg-transparent"
            >
              <Link href="/auth/login">Acceder al Sistema</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-6 py-24">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: Satellite,
              title: "Monitoreo Satelital",
              description: "Datos en tiempo real de múltiples satélites de observación terrestre",
            },
            {
              icon: BarChart3,
              title: "Análisis Avanzado",
              description: "Visualización y análisis de tendencias climáticas históricas",
            },
            {
              icon: Globe,
              title: "Cobertura Global",
              description: "Seguimiento de regiones geográficas en todo el mundo",
            },
            {
              icon: Shield,
              title: "Alertas Tempranas",
              description: "Sistema de notificaciones para eventos climáticos severos",
            },
          ].map((feature) => (
            <div key={feature.title} className="rounded-lg border border-slate-800 bg-slate-900/50 p-6 backdrop-blur">
              <div className="mb-4 inline-flex rounded-lg bg-blue-500/10 p-3">
                <feature.icon className="h-6 w-6 text-blue-400" />
              </div>
              <h3 className="mb-2 text-lg font-semibold text-white">{feature.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-6 py-24">
        <div className="rounded-2xl border border-slate-800 bg-gradient-to-r from-blue-900/50 to-slate-900/50 p-12 text-center backdrop-blur">
          <h2 className="mb-4 text-3xl font-bold text-white">¿Listo para comenzar?</h2>
          <p className="mb-8 text-lg text-slate-300">Únete a la plataforma líder en monitoreo climático satelital</p>
          <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
            <Link href="/auth/sign-up">Crear Cuenta Gratuita</Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/50 py-8">
        <div className="container mx-auto px-6 text-center text-sm text-slate-400">
          <p>© 2025 Climate Monitor. Sistema de Monitoreo Climático Satelital.</p>
        </div>
      </footer>
    </div>
  )
}
